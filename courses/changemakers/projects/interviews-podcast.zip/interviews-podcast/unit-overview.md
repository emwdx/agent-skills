# Unit Overview: Interviewing Employees & Producing a Podcast

## What you’ll do
- In teams, interview people who work at our school.
- Mine stories and ideas that matter to them.
- Turn those conversations into a short podcast that sounds like National Public Radio.
- Share the final audio with classmates and the school community.

## Why it matters
Students practice empathy by listening deeply. They learn how to turn research into narrative, and they experience the full media‑production loop from interview to editing to publishing.

## Learning objectives
1. **Empathic inquiry** – ask open‑ended questions, listen actively, record key points.
2. **Research & storytelling** – structure an interview around a clear story arc (introduction, conflict, resolution).
3. **Media production** – plan, record, edit, and publish audio with basic editing tools.
4. **Reflection & critique** – evaluate the podcast against a rubric and revise based on feedback.

## Assessment summary
- **Final podcast (L4)** – evaluated by a rubric that looks at interview quality, narrative structure, audio clarity, and reflection.
- **Formative checkpoints (L2)** – after the interview guide, after the script draft, and after the first edit.

## Timeline
10 class blocks of 80 minutes each. See the lesson plan for day‑by‑day details.
