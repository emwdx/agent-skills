# Day 1 – Student Activities

**Objective:** Understand the unit and set personal goals for success.

- Watch a short NPR‑style podcast clip that illustrates an engaging interview story.
- In pairs, list two things you notice about tone, structure, or storytelling.
- Form teams of four or five. Each team writes one personal goal they want to achieve during this unit (e.g., *I will ask open‑ended questions*).
- Share your goals with the class. Record common themes on a shared board.
- Commit to the next step you will take before tomorrow’s lesson.