# Day 3 – Student Activities

**Objective:** Practice active listening and give constructive feedback.

- Warm‑up: In pairs, share one thing you noticed about a good interview in the clip from Day 1.
- Role‑play: One student asks questions from their guide; the other answers while the first takes notes on listening habits (e.g., nodding, paraphrasing, asking follow‑ups).
- Peer review: Groups rotate so each pair reviews the notes of another group. Provide one strength and one suggestion for improving listening.
- Reflection: Each student writes a short reflection on what they learned about their own listening style.
- Commit to applying one listening improvement before the next class.