# Day 4 – Student Activities

**Objective:** Prepare for field interviews and set up recording equipment.

- Review the interview‑guide you created and pick two staff members to interview. Record their names, roles, and a brief purpose sentence.
- Test a simple recording device (phone or recorder). Record a short 30‑second voice clip; check that levels are not clipping and that background noise is minimal.
- Draft a *field checklist* that lists: location, time, equipment needed, backup plan, and a brief note on how you’ll keep the interview focused.
- Share your checklist with another group. Identify one strength and one suggestion for improvement.
- Revise the checklist based on feedback.
- Save the final checklist in the shared folder and commit to a date/time for your first interview.