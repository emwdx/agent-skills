# Day 5 – Student Activities

**Objective:** Conduct the first round of interviews and capture key moments.

- Review your interview guide and field checklist. Confirm dates and locations with your assigned staff members.
- Arrive 10 minutes early, set up your recording device, and test levels.
- Conduct the interview, speaking only when prompted by your guide. Keep a brief note sheet next to you for key moments (quotes, emotions, turning points).
- After the interview, label the audio file with: *TeamName_IntervieweeRole_Date* and back‑up it in the shared folder.
- Using the transcription rubric, transcribe the most compelling 2–3 minutes of the conversation. Focus on preserving tone and intent.
- Save the transcript as *TeamName_IntervieweeRole_Date_transcript.txt* in the shared folder.
- Commit to sending a short reflection email outlining one insight you gained from the interview.