# Day 2 – Student Activities

**Objective:** Plan and draft an interview guide.

- Review the interview‑guide template you received in the resources folder.
- In your team, decide which staff role you’ll target next and write three core questions that explore their experience.
- Draft follow‑up prompts for each main question (at least two per question).
- Share your draft guide with another group; give one strength and one suggestion to improve clarity or depth.
- Revise your guide based on the feedback.
- Save the final guide in the shared folder and commit to a date/time for your first interview.