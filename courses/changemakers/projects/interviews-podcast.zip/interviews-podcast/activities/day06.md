# Day 6 – Student Activities

**Objective:** Finish remaining interviews, organize recordings, and transcribe key moments.

- Return to your scheduled staff members. If any interview was missed the previous day, complete it now.
- Label each new audio file with *TeamName_IntervieweeRole_Date* and back‑up in the shared folder.
- Using the transcription rubric, transcribe the most compelling 2–3 minutes of every interview you completed today.
- Save each transcript as *TeamName_IntervieweeRole_Date_transcript.txt*.
- In a brief group discussion, identify one theme that appears across the interviews so far.
- Commit to refining your story map in tomorrow’s lesson based on this theme.