# Lesson Plan: Interviewing Employees & Podcast Production

## Overview
In ten 80‑minute blocks, teams will learn how to conduct empathetic interviews with school staff, craft a narrative script, record and edit an audio podcast, and reflect on the process.

## Daily Structure (10 days)
### Day 1 – Introduction & Goal Setting
- **0–10 min**: Hook. Show a short NPR‑style clip that illustrates a powerful interview story. Ask students what they notice about tone and structure.
- **10–25 min**: Set expectations. State the unit goal: *Create an 8‑minute podcast that tells a staff member’s story.* List the learning objectives.
- **25–35 min**: Clarify success criteria. Show the rubric preview and explain each criterion in plain language.
- **35–50 min**: Form groups of four or five. Have teams write down one personal goal they want to achieve during this unit.
- **50–65 min**: Share goals. Each group says its goal aloud; teacher records common themes on the board.
- **65–80 min**: Quick check‑in. Ask each team to state the next step they will take before tomorrow.

### Day 2 – Interview Planning
- **0–10 min**: Review listening skills. Teacher demonstrates a short active‑listening exercise; students practice in pairs.
- **10–30 min**: Brainstorm interview topics. Each group writes three staff roles they want to interview and one key question for each.
- **30–45 min**: Draft an interview guide template. Teams fill out the template with open‑ended questions, follow‑ups, and a brief ice‑breaker.
- **45–60 min**: Peer review. Groups swap guides; each team marks at least two strengths and one improvement suggestion.
- **60–70 min**: Refine guide based on feedback.
- **70–80 min**: Commit to a schedule. Teams choose two staff members, book appointments, and write the interview plan in a shared doc.

### Day 3 – Practicing Listening
- **0–10 min**: Warm‑up. Students share what they think makes a good interview.
- **10–35 min**: Role‑play. In pairs, one student asks questions from the guide while the other answers; then swap roles.
- **35–50 min**: Group critique. Each pair reports one listening habit that helped or hindered the conversation.
- **50–65 min**: Teacher consolidates common pitfalls and writes a quick checklist on the board.
- **65–80 min**: Students revise their guides using the checklist, focusing on phrasing questions to encourage elaboration.

### Day 4 – Fieldwork Prep
- **0–15 min**: Discuss logistics. Teacher explains how to use the school’s interview scheduling tool and what equipment is needed.
- **15–35 min**: Students practice setting up a simple recording device (phone or recorder) in a quiet space, testing levels.
- **35–55 min**: Fieldwork plan. Teams finalize who they will interview, when, and how they will capture audio.
- **55–70 min**: Teacher reviews each team’s plan; suggests adjustments for time, location, or backup options.
- **70–80 min**: Each group writes a brief “field checklist” to bring on the day of the interview.

### Day 5 – Conducting Interviews (Part 1)
- **0–10 min**: Quick warm‑up. Students review their field checklists.
- **10–50 min**: Teams conduct first round of interviews, recording audio and taking brief notes on key moments.
- **50–70 min**: Immediate debrief. Groups share one insight they gained during the interview.
- **70–80 min**: Teacher notes common themes across groups and outlines next steps for data organization.

### Day 6 – Conducting Interviews (Part 2) & Data Organization
- **0–10 min**: Review day‑5 insights. Students decide which moments to transcribe.
- **10–45 min**: Teams finish remaining interviews, ensuring each recording is labeled and backed up.
- **45–60 min**: Transcription sprint. Each group transcribes the most compelling 2–3 minutes of each interview.
- **60–70 min**: Group share. Students highlight a quote that captures an emotion or turning point.
- **70–80 min**: Teacher provides quick feedback on transcription accuracy and notes organization.

### Day 7 – Story Mapping & Script Drafting
- **0–15 min**: Introduce story arc: Hook, Conflict, Resolution. Show a simple template.
- **15–35 min**: Teams map interview insights onto the arc, labeling each section with a key idea or quote.
- **35–55 min**: Draft script. Students write a concise narration that weaves the mapped ideas into a 8‑minute flow.
- **55–70 min**: Peer review. Groups swap scripts; each team marks clarity of story, audio cues, and pacing.
- **70–80 min**: Revise script based on feedback.

### Day 8 – Audio Recording & Editing Basics
- **0–10 min**: Teacher demonstrates basic editing tools (cut, fade, noise reduction).
- **10–35 min**: Students record a short segment of their script using the recorded interview clips as soundbites.
- **35–55 min**: Edit session. Teams cut excess silence, add fades, and insert transitions between segments.
- **55–70 min**: Listen in groups; each student notes one audio improvement needed.
- **70–80 min**: Teacher shares quick checklist for final polish (volume levels, background noise).

### Day 9 – Final Edit & Peer Review
- **0–15 min**: Teams finalize edits based on last‑minute feedback.
- **15–35 min**: Submit podcast file to the shared folder and upload a short reflection note explaining one design choice.
- **35–55 min**: Peer review. Each group listens to two other podcasts, using the rubric as a guide, and writes a brief comment.
- **55–70 min**: Groups incorporate peer comments into a second‑draft edit.
- **70–80 min**: Teacher circulates final rubrics and reminds students of submission deadlines.

### Day 10 – Reflection, Showcase & Assessment
- **0–20 min**: Showcase. Each group plays its podcast for the class; classmates answer two quick questions about what they heard.
- **20–35 min**: Reflective prompts. Students complete a short reflection on their learning and how the process could improve.
- **35–55 min**: Teacher evaluates podcasts using the rubric, giving written feedback.
- **55–70 min**: Celebration. Share highlights from the unit and discuss next steps for media projects.
- **70–80 min**: Closure. Students share one takeaway they will apply to future work.

## Teacher Moves
- After each activity, ask students to articulate a learning point in one sentence.
- Highlight common listening pitfalls (e.g., interrupting, asking closed questions) and offer concrete fixes.
- Provide quick checklists before recording to ensure audio quality: proper mic placement, quiet room, test levels.
- Encourage peer feedback by modeling how to give constructive comments using the rubric language.

## Resources
- Interview guide template (`interview-guide.md`)
- Script template (`script-template.md`)
- Editing checklist (`editing-guide.md`)
- Rubric (`rubric.md`)
- Reflection prompts (`reflection-prompts.md`)
