# Assessment Overview

This unit is scaffolded around the Changemakers proficiency scales (L2‑L4). Each checkpoint is a **single‑level** assessment that builds toward an L4 final podcast.

| Checkpoint | Assignment | Rubric | Scale | Group/Individual |
|---|---|---|---|---|
| **Day 1 – Goal Setting** | Reflection on personal learning goal | N/A (teacher observation) | L2 | Individual |
| **Day 2 – Interview Guide** | Draft interview guide | *Interview Guide Rubric* | L2 | Group |
| **Day 3 – Listening Practice** | Peer‑review of role‑play notes | N/A | L2 | Individual |
| **Day 4 – Fieldwork Prep** | Field checklist & schedule | N/A | L2 | Group |
| **Day 5–6 – Conducting Interviews** | Transcription of key moments | *Transcription Rubric* (planned) | L3 | Group |
| **Day 7 – Story Mapping & Script Draft** | Narrative script draft | *Script Draft Rubric* | L3 | Group |
| **Day 8 – Audio Recording** | First edit of audio segments | *Editing Rubric* (planned) | L3 | Group |
| **Day 9 – Final Edit & Peer Review** | Revised podcast file + reflection note | N/A | L3 | Group |
| **Day 10 – Showcase & Assessment** | Final 8‑minute podcast | *Final Podcast Rubric* | L4 | Group |

The progression follows the competency growth model: foundational skills (L2) in early checkpoints, independent mastery (L3) mid‑unit, and synthesis/sophistication (L4) for the final product. Each rubric focuses on observable evidence of the targeted level and is linked to a specific assignment.
