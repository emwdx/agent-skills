# Transcription Rubric (L3)

**Assessment type:** Group

| Criterion | L3 Description |
|---|---|
| Accuracy | Transcribed text reflects the spoken words, including key inflections and emphasis. |
| Completeness | All 2–3 minute excerpts are fully captured with minimal omissions. |
| Annotation of Tone | The transcript includes brief notes on speaker tone or emotion when relevant to meaning. |
| Formatting | Text is neatly organized by speaker and time stamps for easy reference in the script. |

**Note:** This rubric targets L3 proficiency—students demonstrate independent, high‑quality transcription with evidence of planning.