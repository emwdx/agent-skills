# Final Podcast Rubric (L4)

**Assessment type:** Group

| Criterion | L4 Description |
|---|---|
| Story Depth & Insight | The podcast demonstrates a sophisticated synthesis of interview material, revealing complex stakeholder perspectives and meaningful implications for the school community. |
| Communication Quality | Language is engaging, precise, and tailored to an NPR‑style audience; pacing and tone sustain listener interest throughout the 8‑minute duration. |
| Technical Excellence | Audio levels are balanced, background noise is minimal, transitions are seamless, and sound design (music, effects) enhances storytelling without distracting. |
| Collaboration & Cohesion | All team members contribute evidence of planning, editing, and reflection; the final product reflects shared ownership and clear division of responsibilities. |
| Advocacy Impact | The podcast articulates actionable insights or calls to action that could influence school practices or policies, showing a clear link between the interviewee’s experiences and broader community outcomes. |

**Relevant Proficiency Scale Descriptors**
- **Communication L4:** "Adapts tools and strategies to diverse audiences while applying sophisticated craftsmanship." 
- **Collaboration L4:** "Articulates and applies collaborative practices tailored to team context and dynamics." 
- **Action & Advocacy L4:** "Completes meaningful change with sustained community impact or plans for ongoing impact." 
- **Creativity L4 (optional):** Demonstrates in‑depth synthesis and application of ideas with complexity or integration.

**Note:** This rubric targets L4 proficiency—students demonstrate synthesis, sophistication, and stakeholder integration beyond L3 criteria.