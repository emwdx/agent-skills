# Personal Learning Goal Reflection Rubric (L2)

**Assessment type:** Individual

| Criterion | L2 Description |
|---|---|
| Goal clarity | The goal is specific, measurable, and tied to the unit’s learning outcomes. |
| Action plan | The student outlines a concrete next step they will take before the next lesson. |
| Self‑reflection depth | The reflection shows awareness of strengths and areas for growth related to listening or inquiry skills. |

**Note:** This rubric focuses on foundational evidence of intent and planning.