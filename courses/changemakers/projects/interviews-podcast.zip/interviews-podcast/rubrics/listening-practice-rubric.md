# Listening Practice Rubric (L2)

**Assessment type:** Individual

| Criterion | L2 Description |
|---|---|
| Active Listening | The student uses body language and verbal cues (e.g., nodding, paraphrasing) to show attentiveness during the role‑play. |
| Follow‑up Quality | When prompted, the student asks at least one open‑ended follow‑up that deepens the conversation. |
| Reflection Depth | In the written reflection, the student identifies a personal listening strength and an area for improvement. |

**Note:** This rubric focuses on L2 proficiency—students demonstrate foundational listening skills with teacher support.