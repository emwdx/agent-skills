# Editing Rubric (L3)

**Assessment type:** Group

| Criterion | L3 Description |
|---|---|
| Audio Clarity | Levels are balanced, background noise is minimal, and transitions are smooth. |
| Story Flow | The edited podcast follows the script’s hook‑conflict‑resolution structure with natural pacing. |
| Technical Precision | Cuts remove unnecessary pauses; fades and crossfades enhance listening experience. |
| Collaboration & Revision | Teams discuss edits, give constructive feedback, and integrate changes before finalizing. |

**Relevant Proficiency Scale Descriptors**
- **Communication L3:** "Communicates information in an organized, engaging way with strong content‑specific language." 
- **Collaboration L3:** "Communicates clearly, participates actively, and fulfills responsibilities within the team." 
- **Action & Advocacy L3:** "Implements solutions with stakeholder feedback and analyzes impact." 

**Note:** This rubric targets L3 proficiency—students demonstrate independent, high‑quality editing that reflects planning and teamwork.