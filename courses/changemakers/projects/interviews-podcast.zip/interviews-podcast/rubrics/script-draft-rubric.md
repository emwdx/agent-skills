# Script Draft Rubric (L3)

**Assessment type:** Group

| Criterion | L3 Description |
|---|---|
| Story Arc Clarity | The script follows a clear hook‑conflict‑resolution structure and each section transitions smoothly. |
| Use of Interview Excerpts | At least three distinct interview quotes are integrated naturally to support the narrative. |
| Language & Tone | Spoken language is engaging, concise, and appropriate for an NPR‑style audience. |
| Audio Planning | The script anticipates audio elements (soundbites, music cues) and indicates where they will be placed. |

**Note:** This rubric targets L3 proficiency—students demonstrate independent, high-quality storytelling with evidence of planning.