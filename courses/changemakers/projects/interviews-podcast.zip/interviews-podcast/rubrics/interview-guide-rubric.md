# Interview Guide Rubric – Communication

**Assessment type:** Group
**Primary competency:** Communication

| Criterion | L2 (Communication) | L3 (Communication) | L4 (Communication) |
|---|---|---|---|
| Question relevance | Plans communication with awareness of audience, organization, and conventions. All questions are open‑ended, tied to the interview purpose, and encourage elaboration. | Communicates information in an organized, engaging way with strong content‑specific language. Questions are clear, concise, and tailored to the interviewee’s context. | Adapts tools and strategies to diverse audiences while applying sophisticated craftsmanship. Questions anticipate follow‑ups that deepen understanding and reflect advanced listening skills. |
| Depth of follow‑up | Each main question is supported by at least two probing prompts that help the interviewee expand on their answer. | Follow‑ups are open‑ended and encourage elaboration, demonstrating independent inquiry. | Probing prompts reveal complex insights and demonstrate mastery of conversational dynamics, integrating stakeholder perspectives. |
| Clarity & conciseness | Questions use plain language, avoid jargon, and are short enough to be read aloud without confusion. | Language is precise and descriptive, engaging the listener. | Language is nuanced, compelling, and fully tailored to an NPR‑style audience, enhancing narrative flow. |
| Alignment with purpose | The guide clearly states who is being interviewed and why, framing context for both interviewer and interviewee. | Purpose is integrated into the structure of questions, guiding the conversation toward meaningful insights. | Purpose drives every question, demonstrating deep alignment with stakeholder narratives and setting a sophisticated story arc. |

**Note:** This rubric focuses on L2–L4 proficiency—students demonstrate progression from foundational planning to advanced, audience‑centric communication.